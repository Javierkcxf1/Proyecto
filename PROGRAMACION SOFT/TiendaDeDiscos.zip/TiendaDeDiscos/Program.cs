﻿// See https://aka.ms/new-console-template for more information
public class Clientes
{
    public int Id { get; set; }
    public string? NombreCliente { get; set; }
    public string? DireccionCliente { get; set; }
    public string? TelefonoCliente { get; set; }

}
public class Artistas
{
    public int Id { get; set; }
    public string? NombreArtista { get; set; }
    public string? NombreArtistico { get; set; }
    public string? GeneroMusical { get; set; }

}
public class Discos
{
    public int Id { get; set; }
    public int Artista { get; set; } //Id del artista clave foranea
    public string? NombreDisco { get; set; }
    public DateTime FechaLanzamiento { get; set; }
    public string? Descripcion { get; set; }
    public Artistas? _Artista { get; set; } // Relacion con artistas

}
public class Formatos
{
    public int Id { get; set; }
    public string? TipoFormato { get; set; }
    public string? Material { get; set; }
}
public class Pagos
{
    public int Id { get; set; }
    public string? TipoPago { get; set; }
    public DateTime FechaPago { get; set; }
    public double MontoTotal { get; set; }
}
public class Ordenes
{
    public int Id { get; set; }
    public DateTime FechaPago { get; set; }
    public int Cliente { get; set; } //Id del cliente clave foranea
    public int Pago { get; set; } //Id del pago clave foranea
    public double Total { get; set; }
    public Clientes? _Cliente { get; set; } //Relacion con cliente
    public Pagos? _Pago { get; set; } //Relacion con pagos
}
public class Inventarios
{
    public int Id { get; set; }
    public int Disco { get; set; } //Id del disco clave foranea 
    public string? Ubicacion { get; set; }
    public int StockTotal { get; set; }
    public Discos? _Discos { get; set; } //Relacion con discos
}
public class OrdenesDiscos
{
    public int Id { get; set; }
    public int Orden { get; set; } //Id de la orden clave foranea
    public int Disco { get; set; } //Id del disco clave foranea
    public int Formato { get; set; } //Id del formato clave foranea
    public int Cantidad { get; set; }
    public double ValorUnitario { get; set; }
    public Ordenes? _Ordenes { get; set; } //Relacion con ordenes
    public Discos? _Disco { get; set; } //Relacion con disco
    public Formatos? _Formato { get; set; } //Relacion con formato

}

public class InventariosFormatos
{
    public int Id { get; set; }
    public int Inventario { get; set; } //Id del inventario clave foranea 
    public int Formato { get; set; } //Id del formato clave foranea
    public int StockTotal { get; set; }
    public Inventarios? _Inventarios { get; set; } //Relacion con inventarios
    public Formatos? _Formatos { get; set; } //Relacion con formatos

}